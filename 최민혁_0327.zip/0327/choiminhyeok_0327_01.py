# 제목 : if ~ elif Review
# 이름 : 최민혁
year = int(input("연도를 입력하세요:"))

if year >= 2024 and year <= 2030:
    print("가까운 시간")

elif year <= 2050:
    print("비교적 먼 시간")
else:
    print("먼 시간")
    