# 제목: 문자열 연산자 01 p.26
# 이름: 최민혁

str1="선문대"
str2="컴퓨터공학부"
str3=str1+str2
var1=3
var2=4
var3=var1+var2

print("안녕"+ "하세요")
print(var1*var2)
print(str1*3)
print(str2*var2)

print(str3)
print(var3)
