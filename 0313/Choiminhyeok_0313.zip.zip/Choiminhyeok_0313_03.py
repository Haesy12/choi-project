# 제목: 문자 선택 연산자(인덱싱과 슬라이싱),len()함수
# 이름: 최민혁

univ_1="선문대학교"
univ_2="서울대학교"

print(univ_1[3])
print(univ_1[2:4])
print(univ_1[:4])
print(univ_1[1:])
print('size of univ_1:', len(univ_1))

print("안녕하세요"[2])
print("안녕하세요"[2:4])
print("size of 안녕하세요:", len("안녕하세요"))
