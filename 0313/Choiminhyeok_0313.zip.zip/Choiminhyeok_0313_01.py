# 제목: 변수 이해하기
# 이름: 최민혁
a=True
b=False
c=3
d=3.14
e='K'
f="sunmoon"
g='Choi'
#print=(f"a: {a} ,b: {b} ,c: {c} ,d: {d} ,e: {e},f: {f} ,g: {g}")
print=(f"a: {type(a)} ,c: {type(c)} ,e: {type(e)},f: {type(f)}")
